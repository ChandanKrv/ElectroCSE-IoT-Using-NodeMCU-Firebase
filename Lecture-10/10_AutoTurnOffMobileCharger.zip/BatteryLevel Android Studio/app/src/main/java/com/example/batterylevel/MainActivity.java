package com.example.batterylevel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    TextView display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);

       final FirebaseDatabase database = FirebaseDatabase.getInstance();
      final  DatabaseReference myRefFullyCharged = database.getReference("fullyCharged");

        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                Integer batLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL,0);
                display.setText("Battery"+batLevel.toString()+"% Charged");
                 if(batLevel > 99){
                     myRefFullyCharged.setValue(1);
                 }else{
                     myRefFullyCharged.setValue(0);
                 }
            }
        };

        registerReceiver(broadcastReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

    }
}